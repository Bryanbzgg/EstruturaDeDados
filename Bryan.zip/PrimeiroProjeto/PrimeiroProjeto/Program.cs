﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("qual teu nome patrao");
        string nome = Console.ReadLine();
        Console.WriteLine("seu nome é " + nome);
    }
}